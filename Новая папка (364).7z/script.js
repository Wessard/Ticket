/* Watch */
window.onload = function() {
    setInterval(()=> {
        var seconds = new Date().getSeconds();
        document.querySelector('.sec').innerHTML = (seconds < 10 ? '0' : '') + seconds;
        var minutes = new Date().getMinutes();
        document.querySelector('.min').innerHTML = (minutes < 10 ? '0' : '') + minutes
        var hours = new Date().getHours();
        document.querySelector('.hou').innerHTML = (hours < 10 ? '0' : '') + hours
    }, 1000)
}
/* Seats objects price */

const rows = {
    firstRowPrice: {
        name: 'Minimal',
        amount: 0,
        price: 12500,
        get Sum() {
            return this.price * this.amount
        }
    },
    secRowPrice: {
        name: 'Medium',
        amount: 0,
        price: 25500,
        get Sum() {
            return this.price * this.amount
        }
    },
    thirdRowPrice: {
        name: 'High',
        amount: 0,
        price: 43500,
        get Sum() {
            return this.price * this.amount
        }
    },
}
/* Seats hover eff */
const priceInfo = document.querySelector('.cinema__footer-price-desc')
const minSeats = document.querySelectorAll('.minimal-rows');
// const medSeats = document.querySelectorAll('.medium-rows');
// const HighSeats = document.querySelectorAll('.high-rows');
function addCol () {
    for(let i = 0; i < minSeats.length; i++) {
        minSeats[i].addEventListener('click', function() {
            if(this.classList.contains('active')) {
                if(rows.firstRowPrice.amount <= 0) {
                    rows.firstRowPrice.amount--;
                }
                
                else { 
                    rows.firstRowPrice.amount = 0
                }
                this.classList.remove('active')
            }
            else {
                this.classList.add('active')
            }
        }     
    )}
}
addCol()
function addSum() {
    for(let i = 0; i < minSeats.length; i++) {
       
            minSeats[i].addEventListener('click', ()=> {
                rows.firstRowPrice.amount++
                priceInfo.innerHTML = rows.firstRowPrice.Sum
                
            })
        }
}
addSum()